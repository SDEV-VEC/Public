Extract this package, then open download.html in a current Chrome, Edge, Firefox or Safari browser.
Select all four part-*.bin files, paste the separately supplied key, and click Unlock and download ZIP.
If prompted, allow the browser to save the ZIP. The resulting ZIP is the original task submission.

Decryption happens locally using AES-256-GCM. The page makes no network requests.
Keep the key private: anyone who has both this package and the key can decrypt it.
Do not upload this encrypted wrapper to the task platform; upload the ZIP it unlocks.
